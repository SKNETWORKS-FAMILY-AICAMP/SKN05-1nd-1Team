import pymysql
import pandas as pd

# 데이터베이스 연결 설정 함수
# MySQL 데이터베이스에 연결하는 함수로, 연결 객체를 반환한다.
def get_db_connection():
    conn = pymysql.connect(
        host='localhost',       # 데이터베이스 호스트 주소 (로컬호스트)
        user='root',            # 데이터베이스 사용자 이름 (루트 계정 사용)
        password='',            # 비밀번호는 빈값으로 설정되어 있음
        database='pj1',         # 사용할 데이터베이스 이름 (pj1)
        charset='utf8mb4',      # UTF-8 인코딩을 사용하여 한글, 이모지 등을 처리할 수 있음
        cursorclass=pymysql.cursors.DictCursor  # 결과를 딕셔너리 형태로 반환
    )
    return conn

# CAR_FAQ 데이터 읽기 함수
# 사용자가 입력한 검색어를 질문과 답변에서 찾아 해당 브랜드의 FAQ 데이터를 가져오는 함수
def get_faq_data(search_query=None):
    connection = get_db_connection()
    try:
        with connection.cursor() as cursor:
            # 질문과 답변에 대해 검색어를 적용하여 데이터를 가져오는 SQL 쿼리
            sql = """
            SELECT brand_name, question, answer
            FROM CAR_FAQ 
            WHERE question LIKE %s OR answer LIKE %s
            """
            # SQL 쿼리에 맞는 검색어 생성 (LIKE 사용)
            like_query = f"%{search_query}%"
            # 쿼리 실행
            cursor.execute(sql, (like_query, like_query))
            # 결과를 fetch하여 pandas DataFrame으로 반환
            result = cursor.fetchall()
            return pd.DataFrame(result)
    finally:
        # DB 연결 종료
        connection.close()

# Service_Centers 데이터 읽기 함수
# 브랜드 이름과 선택적으로 지역 검색어를 사용하여 서비스 센터 데이터를 가져오는 함수
def get_service_center_data(brand_name=None, search_query=None):
    connection = get_db_connection()
    try:
        with connection.cursor() as cursor:
            # 지역 검색어가 있는 경우
            if search_query:
                sql = """
                SELECT center_name, address AS location, phone_number 
                FROM Service_Centers 
                WHERE brand_name = %s AND address LIKE %s
                """
                # LIKE 조건을 사용하여 검색어 설정
                like_query = f"%{search_query}%"
                # 쿼리 실행
                cursor.execute(sql, (brand_name, like_query))
            else:  # 지역 검색어가 없는 경우 브랜드 이름으로만 검색
                sql = """
                SELECT center_name, address AS location, phone_number 
                FROM Service_Centers 
                WHERE brand_name = %s
                """
                cursor.execute(sql, (brand_name,))
                
            # 결과를 fetch하여 pandas DataFrame으로 반환
            result = cursor.fetchall()
            return pd.DataFrame(result)
    finally:
        # DB 연결 종료
        connection.close()

# 서비스 센터 테이블에서 브랜드 이름을 중복 없이 가져오는 함수
# 드롭다운 필터 등에서 사용될 수 있음
def get_service_center_brands():
    connection = get_db_connection()
    try:
        query = "SELECT DISTINCT brand_name FROM Service_Centers"
        df = pd.read_sql(query, connection)
        return df["brand_name"].tolist()
    finally:
        connection.close()

# 차량 판매 대시보드를 위한 필터링된 데이터를 가져오는 함수
# 다양한 조건(국가, 목적, 성별, 지역, 연도, 검색어)을 기반으로 필터링된 차량 판매 데이터를 반환
def fetch_filtered_data(countries, purposes, genders, region, years, search_query):
    connection = get_db_connection()
    try:
        # 조건이 비어있는 경우 기본값 설정
        if not countries:
            countries = ["국산", "수입"]  # 기본값으로 국산과 수입 차를 포함
        if not purposes:
            purposes = []  # 목적이 비어 있으면 모든 고객 유형을 포함
        if not genders:
            genders = ["남성", "여성"]  # 기본값으로 남성과 여성을 포함
        if not years:
            years = [2023, 2024]  # 기본값으로 2023년과 2024년 포함

        # 검색어에 대한 와일드카드 설정
        search_query_wildcard = f"%{search_query}%"

        # 지역이 전국인 경우 (전국에 걸친 데이터를 가져옴)
        if region == "전국":
            query = f"""
            SELECT GROUP_CONCAT(DISTINCT car_brands.brand_name) AS brand_names, 
            car_models.model_name, car_sales.year,
            GROUP_CONCAT(DISTINCT car_sales.gender) AS genders, 
            SUM(car_sales.count) AS total_count, 
            GROUP_CONCAT(DISTINCT car_brands.country) AS countries
            FROM car_sales
            INNER JOIN car_models ON car_sales.model_id = car_models.id
            INNER JOIN car_brands ON car_models.brand_id = car_brands.id
            WHERE car_brands.country IN ({','.join(['%s'] * len(countries))})
            AND car_sales.customer_type IN ({','.join(['%s'] * len(purposes))})
            AND car_sales.gender IN ({','.join(['%s'] * len(genders))})
            AND car_sales.year IN ({','.join(['%s'] * len(years))})
            AND (car_models.model_name LIKE %s OR car_brands.brand_name LIKE %s)
            GROUP BY car_models.model_name, car_sales.year
            """
            # 파라미터 설정
            params = countries + purposes + genders + years + [search_query_wildcard, search_query_wildcard]
        else:
            # 특정 지역에 대한 데이터 가져오기
            query = f"""
            SELECT region_car_sales.region, car_brands.brand_name, 
            GROUP_CONCAT(DISTINCT car_sales.gender) AS genders, 
            SUM(region_car_sales.count) AS total_count, 
            car_brands.country
            FROM car_sales
            INNER JOIN car_models ON car_sales.model_id = car_models.id
            INNER JOIN car_brands ON car_models.brand_id = car_brands.id
            INNER JOIN region_car_sales ON car_brands.brand_name = region_car_sales.brand
            WHERE region_car_sales.region = %s
            AND car_brands.country IN ({','.join(['%s'] * len(countries))})
            AND car_sales.customer_type IN ({','.join(['%s'] * len(purposes))})
            AND car_sales.gender IN ({','.join(['%s'] * len(genders))})
            AND car_sales.year IN ({','.join(['%s'] * len(years))})
            AND (car_brands.brand_name LIKE %s)
            GROUP BY region_car_sales.region, car_brands.brand_name, car_brands.country
            """
            # 파라미터 설정
            params = [region] + countries + purposes + genders + years + [search_query_wildcard]

        # SQL 쿼리 실행 및 DataFrame으로 변환
        df = pd.read_sql(query, connection, params=params)

        # '개인'과 '법인'이 모두 포함된 경우 데이터를 조합하여 표시
        if '개인' in purposes and '법인' in purposes:
            df['customer_type'] = '개인 + 법인'
        
        return df
    except Exception as e:
        # 쿼리 실행 중 오류 발생 시 에러 메시지 출력
        st.error(f"Error executing query: {e}")
        raise e
    finally:
        # DB 연결 종료
        connection.close()

# 기본 필터 설정 함수
# 대시보드에서 사용되는 필터의 기본값을 반환하는 함수
def get_default_filters():
    return {
        "countries": ["국산", "수입"],
        "purposes": ["개인", "법인"],
        "genders": ["남성", "여성"],
        "years": [2023, 2024],
        "region": "전국",
        "search_query": ""
    }