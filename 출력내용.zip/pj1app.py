import streamlit as st
import pandas as pd
from pj1_connection import get_faq_data, get_service_center_data, get_service_center_brands, fetch_filtered_data, get_default_filters

# Main Page Navigation (In Main Area)
st.title("Welcome to the Vehicle Registration System")

# Display page selector in the main area
selected_page = st.selectbox("Choose a page", ["Vehicle Sales Dashboard", "FAQ", "Service Center"])

# Page selection logic
if selected_page == "Vehicle Sales Dashboard":
    st.title("Vehicle Sales Dashboard")

    # Use columns to align search input and top 10 button
    col1, col2 = st.columns([4, 1])

    with col1:
        # 사용자가 입력한 검색어를 차량 브랜드 또는 모델명으로 필터링하기 위한 입력 상자
        search_query = st.text_input("Search by Vehicle Brand or Model Name", "")
    with col2:
        # 상위 10개 결과를 표시하기 위한 버튼
        show_top_10 = st.button("Show Top 10 Results")

    # Sidebar filters for more specific selections
    st.sidebar.title("Filters")

    # Filter: Year (checkboxes for 2023 and 2024)
    st.sidebar.subheader("Select Years to Compare (Required)")
    # 필터: 사용자가 비교할 연도를 선택하도록 체크박스를 제공 (기본으로 2023년, 2024년이 선택됨)
    years = []
    if st.sidebar.checkbox("2023", value=True):  # Default to checked
        years.append(2023)
    if st.sidebar.checkbox("2024", value=True):  # Default to checked
        years.append(2024)

    # Filter: Purpose (Checkboxes for Personal or Business)
    st.sidebar.subheader("Select Usage Type:")
    # 필터: 사용자가 차량 사용 목적을 선택할 수 있도록 체크박스를 제공
    purpose_options = ["개인", "법인"]
    purposes = []
    for option in purpose_options:
        if st.sidebar.checkbox(option, value=True):  # Default to checked
            purposes.append(option)

    # Disable gender selection for "법인"
    disable_gender = "법인" in purposes  # 법인 선택 시 성별 필터 비활성화

    # Filter: Gender (Checkboxes, disabled for corporations)
    st.sidebar.subheader("Select Gender (Not applicable for corporations):")
    # 필터: 법인이 아닌 경우 성별 필터를 제공
    gender_options = ["남성", "여성"]
    genders = []
    if not disable_gender:
        for option in gender_options:
            if st.sidebar.checkbox(option, value=True):  # Default to checked
                genders.append(option)
    else:
        genders = ["해당 없음"]

    # Filter: Country of Origin (Checkboxes)
    st.sidebar.subheader("Select Vehicle Origin:")
    # 필터: 차량의 원산지를 선택할 수 있는 체크박스
    country_options = ["국산", "수입"]
    countries = []
    for option in country_options:
        if st.sidebar.checkbox(option, value=True):  # Default to checked
            countries.append(option)

    # Filter: Region (Default to "전국" for all regions)
    st.sidebar.subheader("Select Region:")
    # 필터: 지역을 선택할 수 있는 드롭다운 (기본값은 전국)
    region = st.sidebar.selectbox("Region", ["전국", "서울시", "부산시", "대구시", "인천시", "광주시", "대전시", "울산시", 
                                             "경기도", "강원도", "충청북도", "충청남도", "전라북도", "전라남도", "경상북도", 
                                             "경상남도", "제주도"])

    # Fetch the filtered data
    # 사용자가 선택한 필터 조건을 기반으로 데이터를 가져옴
    if not countries and not purposes and not years:
        # If no selections are made, apply default filters
        default_filters = get_default_filters()
        filtered_data = fetch_filtered_data(
            default_filters["countries"], 
            default_filters["purposes"], 
            default_filters["genders"], 
            default_filters["region"], 
            default_filters["years"], 
            default_filters["search_query"]
        )
    else:
        # Fetch data based on the selected filters
        filtered_data = fetch_filtered_data(countries, purposes, genders, region, years, search_query)

    # Display the results based on the region selection
    if region == "전국":
        if not filtered_data.empty:
            st.write(f"Displaying data for {region}, {', '.join(map(str, years))}")
            
            # Show top 10 results
            if show_top_10:
                filtered_data = filtered_data.nlargest(10, 'total_count')
            
            # Display the table for "전국" (excluding region column)
            filtered_data = filtered_data.drop(columns=["region"], errors="ignore")
            st.dataframe(filtered_data)
    else:
        # Show region-specific brand preferences
        st.write(f"Brand Preferences for {region}, {', '.join(map(str, years))}")
        st.dataframe(filtered_data)

elif selected_page == "FAQ":
    st.title("FAQ")

    # FAQ 페이지에서 질문 또는 답변을 검색하기 위한 입력 상자
    search_query = st.text_input("Search FAQ (by question or answer)")

    # Perform search when query is provided
    if search_query:
        # Perform a search within CAR_FAQ table
        faq_results = get_faq_data(search_query)
        
        # Check if results are returned
        if faq_results.empty:
            st.write(f"No FAQ results found for: {search_query}")
        else:
            st.write(f"Displaying FAQ results for: {search_query}")
            st.dataframe(faq_results)

elif selected_page == "Service Center":
    st.title("Service Center")

    # Fetch distinct brand names from Service_Centers table
    service_center_brands = get_service_center_brands()

    # Display brand names as a required dropdown selection (cannot proceed without selecting a brand)
    selected_brand = st.selectbox("Select a Brand (Required)", service_center_brands)

    # Optional location search (can leave it blank)
    searched_location = st.text_input("Insert the Location (Optional)")

    # Fetch and display data based on the selected brand and optional searched location
    if selected_brand:  # Make sure a brand is selected
        # Pass the selected_brand and searched_location to the function
        service_center_results = get_service_center_data(selected_brand, searched_location)
        
        if service_center_results.empty:
            if searched_location:
                st.write(f"No Service Centers found for: {selected_brand} in {searched_location}")
            else:
                st.write(f"No Service Centers found for: {selected_brand}")
        else:
            if searched_location:
                st.write(f"Displaying Service Centers for: {selected_brand} in {searched_location}")
            else:
                st.write(f"Displaying Service Centers for: {selected_brand}")
            st.dataframe(service_center_results)